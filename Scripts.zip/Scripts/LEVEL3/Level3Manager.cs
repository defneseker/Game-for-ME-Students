using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using System.Text.RegularExpressions;

public class Level3Manager : MonoBehaviour
{
    public TMP_InputField no1;
    public TMP_InputField no2;
    public TMP_InputField no3;

    public GameObject instructionsPanel;

    public int GetCurrentLevelNumber()
    {
        // 1. Get the actual text name of the active scene (e.g., "Level15")
        string sceneName = SceneManager.GetActiveScene().name;
        Match match = Regex.Match(sceneName, @"\d+");
        if (match.Success)
        {
            return int.Parse(match.Value);
        }
        return 0;
    }

    int currentLevel;
    void Start()
    {
        if (PlayerPrefs.GetInt("VisitedLevel3", 0) == 1)
        {
            instructionsPanel.SetActive(false);
        }
        currentLevel = GetCurrentLevelNumber();
        PlayerPrefs.SetInt("PreviousSceneIndex", currentLevel);
        PlayerPrefs.Save();
    }
    
    
    public void CheckStep1()
    {
        float val1 = ConvertToFloat(no1.text);
        float val2 = ConvertToFloat(no2.text);
        if (val1 == 10 && val2 == 6)
        {
            Debug.Log("Correct");
            SceneManager.LoadScene("Level3Step1Done");
        }
        else 
        {
            Debug.Log("Incorrect");
            SceneManager.LoadScene("Level3Fail");
        }
    }

    public void CheckStep2()
    {
        float val3 = ConvertToFloat(no3.text);
        float expectedResult = (6 / PlayerPrefs.GetInt("SeVal", 100)) + (10 / PlayerPrefs.GetInt("SutVal", 310));
        if (val3 == expectedResult)
        {
            Debug.Log("Correct");
            SceneManager.LoadScene("Level3Success");
            PlayerPrefs.SetInt("ReachedLevel", currentLevel + 1);
            PlayerPrefs.Save();
        }
        else 
        {
            Debug.Log("Incorrect");
            SceneManager.LoadScene("Level3Fail");
        }
    }

    private float ConvertToFloat(string text)
    {
        if (float.TryParse(text, out float result))
        {
            return result;
        }
        return 0f; 
    }


    public void GoToLevel()
    {
        instructionsPanel.SetActive(false);
        PlayerPrefs.SetInt("VisitedLevel3", 1);
        PlayerPrefs.Save();
    }

    public void OpenInstructions()
    {
        instructionsPanel.SetActive(true);
    }
}
